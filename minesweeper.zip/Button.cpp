#include "Button.h"

sf::Vector2f Button::getPosition()
{
    return currPosition;
}

sf::Sprite* Button::getSprite()
{
    return &currSprite;
}

void Button::setSprite(sf::Sprite* _sprite)
{
    this->currSprite = *(_sprite);
}
Button::Button(sf::Vector2f _position, std::function<void(void)> _onClick) {

    this->currSprite.setPosition(_position);
    this->_onClick = _onClick;

}

void Button::onClick() {
    _onClick();
}

void Button::drawButton(sf::RenderWindow& window){
    window.draw(this->currSprite);
}
void Button::setText(sf::Texture& texture) {
    this->currSprite.setTexture(texture);
}