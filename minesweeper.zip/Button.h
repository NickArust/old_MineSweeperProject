#pragma once
#ifndef MINESWEEPER_BUTTON_H
#define MINESWEEPER_BUTTON_H

#include <SFML/Graphics.hpp>
#include "Toolbox.h"
#include <functional>
class Button
{
public:
    Button(sf::Vector2f _position, std::function<void(void)> _onClick);
    sf::Vector2f getPosition();
    sf::Sprite* getSprite();
    void setSprite(sf::Sprite* _sprite);
    void onClick();
    void drawButton(sf::RenderWindow& window);
    void setText(sf::Texture& texture);


private:
    sf::Sprite currSprite;
    sf::Vector2f currPosition;
    std::function<void(void)> _onClick;
};
#endif