#include "GameState.h"
#include "Toolbox.h"
#include "MineSweeper.h"
#include <fstream>
#include <iostream>
using namespace std;

class ToolBox;
GameState::PlayStatus GameState::getPlayStatus()
{
    return this->currentPlayStatus;
}

void GameState::setPlayStatus(PlayStatus _status)
{ // i used this method to basically assign the tiles and assign the neightbors
    this->currentPlayStatus = _status;
    if(_status == PLAYING) {
        int width = 25;
        int height = 16;
        happy.loadFromFile("images/face_happy.png");
        ToolBox::getInstance()->ToolBox::newGameButton->setText(happy);
        ToolBox::getInstance()->debugMode = false;
        tiles.clear();
        for (int i = 0; i < height; i++) {
            std::vector<Tile> rowVector; // creates the tiles
            for (int j = 0; j < width; j++) {
                sf::Vector2f pos(j * 32, i * 32);
                rowVector.emplace_back(pos);
            }
            tiles.push_back(rowVector);
        }

        int b = 0;
        while (b < 50) {
            int spotx = rand() % (int) 25;
            int spoty = rand() % (int) 16; // randomly assigns the bombs
            if (ToolBox::getInstance()->gameState->getTile(spotx * 32, spoty * 32)->getBomb()) {
                continue;
            } else {
                b++;
                ToolBox::getInstance()->gameState->getTile(spotx * 32, spoty * 32)->setBomb(true);
            }
        }

        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                //assings the neighbors if its inside the map n sets to nullptr else
                if (j - 1 >= 0 && i - 1 >= 0) {
                    neigh[0] = &ToolBox::getInstance()->gameState->tiles.at(i - 1).at(j - 1);
                } else {
                    neigh[0] = nullptr;
                }
                if (i - 1 >= 0) {
                    neigh[1] = &ToolBox::getInstance()->gameState->tiles.at(i - 1).at(j);
                } else {
                    neigh[1] = nullptr;
                }
                if (j + 1 <= width - 1 && i - 1 >= 0) {
                    neigh[2] = &ToolBox::getInstance()->gameState->tiles.at(i - 1).at(j + 1);
                } else {
                    neigh[2] = nullptr;
                }
                if (j - 1 >= 0) {
                    neigh[3] = &ToolBox::getInstance()->gameState->tiles.at(i).at(j - 1);
                } else {
                    neigh[3] = nullptr;
                }
                if (j + 1 <= width - 1) {
                    neigh[4] = &ToolBox::getInstance()->gameState->tiles.at(i).at(j + 1);
                } else {
                    neigh[4] = nullptr;
                }
                if (i + 1 <= height - 1 && j - 1 >= 0) {
                    neigh[5] = &ToolBox::getInstance()->gameState->tiles.at(i + 1).at(j - 1);
                } else {
                   neigh[5] = nullptr;
                }
                if (i + 1 <= height - 1) {
                    neigh[6] = &ToolBox::getInstance()->gameState->tiles.at(i + 1).at(j);
                } else {
                    neigh[6] = nullptr;
                }
                if (i + 1 <= height - 1 && j + 1 <= width - 1) {
                    neigh[7] = &ToolBox::getInstance()->gameState->tiles.at(i + 1).at(j + 1);
                } else {
                    neigh[7] = nullptr;
                }
                ToolBox::getInstance()->gameState->tiles.at(i).at(j).setNeighbors(neigh);
            }
        }
    }
    else if(_status == WIN){
        winr.loadFromFile("images/face_win.png");
        ToolBox::getInstance()->newGameButton->setText(winr);
        for(int i = 0; i < tiles.size(); i++) // if there is a winner, change all the mines to flags and change face
        {
            for(int j = 0; j < tiles[i].size(); j++)
            {
                if(tiles.at(i).at(j).getBomb())
                {
                    tiles.at(i).at(j).setState(Tile::FLAGGED);
                }
            }
        }
    }
    else if(_status == LOSS){
        loser.loadFromFile("images/face_lose.png");
        ToolBox::getInstance()->newGameButton->setText(loser);
        for(int i = 0; i < tiles.size(); i++)
        {
            for(int j = 0; j < tiles[i].size(); j++)
            {
                if(tiles.at(i).at(j).getBomb()) // if there is a loss, show all the bombs and change teh f ace
                {
                    tiles.at(i).at(j).setState(Tile::REVEALED);
                }
            }
        }
    }
}

int GameState::getFlagCount(){
    int count = 0;
    for(int i =0;i<tiles.size();i++){
        for(int j = 0;j<tiles[0].size();j++){
            if(ToolBox::getInstance()->gameState->tiles.at(i).at(j).getState() == Tile::FLAGGED){
                count++; // counts flags
            }
        }
    }
    return count;
}
int GameState::getMineCount() {
    int count=0;
    for(int i =0;i<tiles.size();i++){
        for(int j = 0;j<tiles[0].size();j++){
            if(ToolBox::getInstance()->gameState->tiles.at(i).at(j).getBomb()){
                count++; // counts mines
            }
        }
    }
    return count;
}

Tile *GameState::getTile(int x, int y) {
    if(x<0||x>800&&y<0||y>512){
        return nullptr;
    }
    int xpos = x/32; // gets the tile at pixel value
    int ypos = y/32;
    return &tiles.at(ypos).at(xpos);
}
GameState::GameState(const char *filepath) {

    ifstream file(filepath,ios_base::in);
    vector<vector<string>> fileBoard; // basically loads the file
    string fileLine;
    while(getline(file,fileLine)){
        vector<string> tempLine;
        for(int i = 0;i<fileLine.length();i++){
            tempLine.push_back(fileLine.substr(i,1));
        }
        fileBoard.push_back(tempLine); // stores the values in the board into a vector of vector of strings
    }
    int width = 25;
    int height = 16;
    for(int i=0;i<height;i++){
        for(int j = 0;j<width;j++){
            bool yes = fileBoard.at(i).at(j) == "1"; // if there is a 1 in the spot, set that to bomb
            ToolBox::getInstance()->gameState->GameState::getTile(j*32,i*32)->setBomb(yes);
        }
    }
}
GameState::GameState(sf::Vector2f _dimensions, int _numberOfMines) {
//i couldn't figure this out in time im sorry
}
