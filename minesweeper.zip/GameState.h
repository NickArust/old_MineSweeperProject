#pragma once
#ifndef MINESWEEPER_GAMESTATE_H
#define MINESWEEPER_GAMESTATE_H


#include <SFML/Graphics.hpp>
#include "Tile.h"
#include <vector>
#include "Toolbox.h"

class GameState
{
public:
    enum PlayStatus {WIN, LOSS, PLAYING};
    GameState(sf::Vector2f _dimensions = sf::Vector2f(25, 16), int _numberOfMines = 50);
    GameState(const char* filepath);
    Tile* getTile(int x, int y);
    PlayStatus getPlayStatus();
    void setPlayStatus(PlayStatus _status);
    int getFlagCount();
    int getMineCount();
    std::vector<std::vector<Tile>> tiles;

    std::array<Tile*,8> neigh;
    sf::Texture happy;
    sf::Texture loser;
    sf::Texture winr;

private:
    PlayStatus currentPlayStatus;
};

#endif