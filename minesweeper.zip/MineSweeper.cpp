#include <SFML/Graphics.hpp>
#include <iostream>
#include <fstream>
#include "MineSweeper.h"

void toggleDebugMode() // changes the debug to the opposite of what it is

{
    ToolBox::getInstance()->debugMode = !ToolBox::getInstance()->debugMode;
}

bool getDebugMode() // returns the current debug state
{
    return ToolBox::getInstance()->debugMode;
}


int launch(){ // starts a new game and does the game stuff
    restart();

    return gameLoop();

}
void restart(){
    ToolBox::getInstance()->gameState->setPlayStatus(GameState::PLAYING);
}
void render(){ // draws the stuff
    ToolBox::getInstance()->window.clear(); // clears the window
    for(int i = 0; i < 16; i++) {
        for(int j = 0; j < 25; j++) {
            ToolBox::getInstance()->gameState->getTile(j*32,i*32)->draw(); // draws the tiles
        }
    }

    ToolBox::getInstance()->debugButton->drawButton(ToolBox::getInstance()->window);
    ToolBox::getInstance()->newGameButton->drawButton(ToolBox::getInstance()->window); // draws the buttons
    ToolBox::getInstance()->testButton1->drawButton(ToolBox::getInstance()->window);
    ToolBox::getInstance()->testButton2->drawButton(ToolBox::getInstance()->window);
    int dispCount = ToolBox::getInstance()->gameState->getMineCount() - ToolBox::getInstance()->gameState->getFlagCount(); // the num of mines - flags
    if(dispCount >= 0 ){ // if its positive...
        int holder = dispCount /10;
        int hund = holder /10;
        int ten = holder %10;
        int ones = dispCount%10;
        sf::Texture hText;
        hText.loadFromFile("images/digits.png",sf::IntRect(21*hund,0,21,32));
        sf::Sprite hSprite;
        hSprite.setTexture(hText);
        hSprite.setPosition(0,512); // what i am doing here is basically taking the image from digits and just shifting to get the value I need
        sf::Texture tText;
        tText.loadFromFile("images/digits.png",sf::IntRect(21*ten,0,21,32));
        sf::Sprite tSprite;
        tSprite.setTexture(tText);
        tSprite.setPosition(21,512);
        sf::Texture oText;
        oText.loadFromFile("images/digits.png",sf::IntRect(21*ones,0,21,32));
        sf::Sprite oSprite;
        oSprite.setTexture(oText); // i load and draw each of these and then display the window
        oSprite.setPosition(42,512);
        ToolBox::getInstance()->window.draw(hSprite);
        ToolBox::getInstance()->window.draw(tSprite);
        ToolBox::getInstance()->window.draw(oSprite);
        ToolBox::getInstance()->window.display();
    }
    else{ // if negative...
        int posDisp = -dispCount;
        int ten = (posDisp%100) /10;
        int ones = posDisp%10; // basically the same idea as before but just deals with the minus sign
        sf::Texture hText;
        hText.loadFromFile("images/digits.png",sf::IntRect(210,0,21,32));
        sf::Sprite hSprite;
        hSprite.setTexture(hText);
        hSprite.setPosition(0,512);
        sf::Texture tText;
        tText.loadFromFile("images/digits.png",sf::IntRect(21*ten,0,21,32));
        sf::Sprite tSprite;
        tSprite.setTexture(tText);
        tSprite.setPosition(21,512);
        sf::Texture oText;
        oText.loadFromFile("images/digits.png",sf::IntRect(21*ones,0,21,32));
        sf::Sprite oSprite;
        oSprite.setTexture(oText);
        oSprite.setPosition(42,512);
        ToolBox::getInstance()->window.draw(hSprite);
        ToolBox::getInstance()->window.draw(tSprite);
        ToolBox::getInstance()->window.draw(oSprite);
        ToolBox::getInstance()->window.display();
    }



}
int gameLoop() {
    while (ToolBox::getInstance()->window.isOpen()) {
        sf::Event event;
        while (ToolBox::getInstance()->window.pollEvent(event)) { // while window is open and looking for an event....
            if (event.type == sf::Event::Closed) { // if user tries to close the window, do so
                ToolBox::getInstance()->window.close();
            }
            if (event.type == sf::Event::MouseButtonPressed) { // if user presses button and its the left mouse one
                if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                    sf::Vector2i pos = sf::Mouse::getPosition(ToolBox::getInstance()->window); // position of hte mouse
                    if (pos.x >= 0 && pos.y >= 0 && pos.x < 800 && pos.y < 512 &&
                        ToolBox::getInstance()->gameState->getPlayStatus() == GameState::PlayStatus::PLAYING) { // if its within the board and the game is playing...
                        ToolBox::getInstance()->gameState->getTile(pos.x, pos.y)->onClickLeft(); // does the clicking action on the tile
                        std::array<Tile *, 8> near;
                        near = ToolBox::getInstance()->gameState->getTile(pos.x, pos.y)->getNeighbors();
                        int count = 0;
                        for (int i = 0; i < 8; i++) {
                            if (near[i] != nullptr && near[i]->getBomb()) {
                                count++;
                            }
                        } // counts the number of mines nearby
                        if (!(ToolBox::getInstance()->gameState->getTile(pos.x, pos.y)->getBomb()) && count == 0) {
                            ToolBox::getInstance()->gameState->getTile(pos.x, pos.y)->revealNeighbors1(); // if the tile clicked on isn't a mine and has no bombs near, reveal the neighbors
                        } else if (ToolBox::getInstance()->gameState->getTile(pos.x, pos.y)->getBomb()) {
                            ToolBox::getInstance()->gameState->setPlayStatus(GameState::LOSS); // if it is a bomb, set the game to lost
                        }
                    }
                    if (ToolBox::getInstance()->debugButton->getSprite()->getGlobalBounds().contains(pos.x, pos.y)) {
                       ToolBox::getInstance()->debugButton->onClick();
                    }
                    if (ToolBox::getInstance()->newGameButton->getSprite()->getGlobalBounds().contains(pos.x, pos.y)) {
                        ToolBox::getInstance()->newGameButton->onClick(); // if the user clicks on a button, do the thing
                    }
                    if (ToolBox::getInstance()->testButton1->getSprite()->getGlobalBounds().contains(pos.x, pos.y)) {
                        restart();
                        ToolBox::getInstance()->testButton1->onClick();
                    }
                    if (ToolBox::getInstance()->testButton2->getSprite()->getGlobalBounds().contains(pos.x, pos.y)) {
                        restart();
                        ToolBox::getInstance()->testButton2->onClick();
                    }
                    bool winner = true;
                    for (int i = 0; i < 16; i++) {
                        for (int j = 0; j < 25; j++) {
                            if (!(ToolBox::getInstance()->gameState->getTile(j * 32, i * 32)->getBomb()) &&
                                ToolBox::getInstance()->gameState->getTile(j * 32, i * 32)->getState() !=
                                Tile::REVEALED) {
                                winner = false; // if there is nonmine tile that hasn't been revealed, no winner yet
                                break;
                            }
                        }
                    }
                    if (winner) {
                        ToolBox::getInstance()->gameState->setPlayStatus(GameState::WIN); // change status if needed
                    }
                }
            }
            if(event.type == sf::Event::MouseButtonPressed){
                if(sf::Mouse::isButtonPressed(sf::Mouse::Right)){
                    sf::Vector2i rightPos = sf::Mouse::getPosition(ToolBox::getInstance()->window);
                    ToolBox::getInstance()->gameState->getTile(rightPos.x,rightPos.y)->onClickRight();
                } // if user right clicks, do the thing associated
            }

        }
        render(); // draw the tiles
    }
    return 0;
}

int main(){

    return launch();
}

