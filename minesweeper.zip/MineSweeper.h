#pragma once
#ifndef MINESWEEPER_MINESWEEPER_H
#define MINESWEEPER_MINESWEEPER_H

#include <vector>
#include "Button.h"
#include "GameState.h"
#include "Tile.h"
#include "ToolBox.h"
using namespace std;

int launch();
void restart();
void render();
void toggleDebugMode();
bool getDebugMode();
int gameLoop();
void testLoader(const char* filepath);

#endif //MINESWEEPER_MINESWEEPER_H
