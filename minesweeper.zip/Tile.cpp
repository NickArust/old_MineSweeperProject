#include <iostream>
#include "Tile.h"
#include "Toolbox.h"
Tile::Tile(sf::Vector2f position)
{
    frontText.loadFromFile("images/tile_hidden.png");
    backText.loadFromFile("images/tile_revealed.png");
    backSprite.setTexture(backText);
    frontSprite.setTexture(frontText);
    backSprite.setPosition(position);
    frontSprite.setPosition(position);
    state = HIDDEN; // creates a tile and sets textures
}

sf::Vector2f Tile::getLocation()
{
    return this->backSprite.getPosition();

}

Tile::State Tile::getState()
{
    return this->state;
}

void Tile::setState(State _state)
{
    this->state = _state;
}

void Tile::onClickLeft() {

    if(isMine){ // if clicked on and is mine, change state to exploded and set color to red
        setState(State::EXPLODED);
        backSprite.setColor(sf::Color::Red);
    }
    else{
        setState(State::REVEALED); // if not mine, set to revealed
    }

}
void Tile::onClickRight()
{
    if (ToolBox::getInstance()->gameState->getPlayStatus() != GameState::PLAYING || getState() != State::HIDDEN && getState() != State::FLAGGED) {
        return; // if not playing or tile is revealed already
    }

    isFlag = !isFlag; // sets flag to not flag
    if(isFlag)
    {
        setState(State::FLAGGED); // sets state to flagged
        if(clickEvent.type == sf::Event::MouseButtonPressed)
        {
            if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
            {
                setState(State::FLAGGED);
            }
        }
    }
    else
    {
        setState(State::HIDDEN); // if flagged already, change it to not flagged
    }
}
void Tile::draw(){
    sf::Texture revel;
    revel.loadFromFile("images/tile_revealed.png");
    sf::Texture hide;
    hide.loadFromFile("images/tile_hidden.png");
    backSprite.setTexture(hide); // sets the textures

    sf::Texture flag1;
    flag1.loadFromFile("images/flag.png");
    sf::Texture bombtext;
    bombtext.loadFromFile("images/mine.png");
    if(ToolBox::getInstance()->debugMode && isMine || getState() == State::EXPLODED){
        frontSprite.setTexture(bombtext); // if the tile is a bomb or already exploded, change the texture to bomb
        backSprite.setTexture(hide);
    }
    else if(getState() == State::REVEALED){
        frontSprite.setTexture(getText());
        backSprite.setTexture(revel);  // if it isn't a bomb, get the texture based on neighbors
    }
    else if(getState() == State::FLAGGED){
        frontSprite.setTexture(flag1);
    } // if flagged, set sprite to flag
    else{
        frontSprite.setTexture(hide);
    } // if no changes, change front sprite to hidden
    ToolBox::getInstance()->window.draw(backSprite);
    ToolBox::getInstance()->window.draw(frontSprite);




}
sf::Texture& Tile::getText(){ // gets the texture based on neighbors

    bombText.loadFromFile("images/mine.png");
    if(getBomb()){
        return bombText; // if the tile is a bomb, return as such
    }
    int count = 0;
    for(int i =0;i<8;i++){
        if(neighbors[i] != nullptr && neighbors[i]->getBomb()){
            count++; // counts the bombs in the neighbors
        }
    }



    one.loadFromFile("images/number_1.png");
    two.loadFromFile("images/number_2.png");
    three.loadFromFile("images/number_3.png");
    four.loadFromFile("images/number_4.png");
    five.loadFromFile("images/number_5.png");
    six.loadFromFile("images/number_6.png");
    seven.loadFromFile("images/number_7.png"); // loads textures
    eight.loadFromFile("images/number_8.png");
    revealed.loadFromFile("images/tile_revealed.png");

    switch(count){ // switch based on textures
        default:
            return revealed;
        case 1:
            return one;

        case 2:
            return two;

        case 3:
            return  three;

        case 4:
            return four;

        case 5:
            return five;

        case 6:
           return six;

        case 7:
            return seven;
        case 8:
           return eight;


    }
}
void Tile::revealNeighbors() {
    for(Tile* i : neighbors){ // for i in neighbors,
        if(i != nullptr){ // if tile is in the board
            if (i->getState()==State::HIDDEN&& !(i->getBomb())){ // and if tile is hidden and not a bomb
                i->setState(State::REVEALED); // make it revealed
                int count = 0;
                for(int j =0;j<8;j++){
                    if(neighbors[j] != nullptr && neighbors[j]->getBomb()){
                        count++;
                    }
                } // counts mines near the tile
                if(count == 0){ // if the tile has no bombs nearby, reveal those
                    i->revealNeighbors();
                }
            }
        }
    }
}
void Tile::revealNeighbors1() { // public version of the protected method, i coudln't figur out how to do the protected stff
for(Tile* i : neighbors){
    if(i != nullptr){
        if (i->getState()==State::HIDDEN&& !(i->getBomb())){
            i->setState(State::REVEALED);
            int count = 0;
            for (int i = 0; i < 8; i++) {
                if (neighbors[i] != nullptr && neighbors[i]->getBomb()) {
                    count++;
                }
            }
            if(count == 0){
                i->revealNeighbors1();
            }
        }

        }
    }
}

void Tile::setNeighbors(std::array<Tile *, 8> _neighbors)
{
    neighbors = _neighbors;
}

std::array<Tile*, 8>& Tile::getNeighbors()
{
    return neighbors;
}
