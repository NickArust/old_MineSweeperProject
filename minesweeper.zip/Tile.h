#pragma once
#ifndef MINESWEEPER_TILE_H
#define MINESWEEPER_TILE_H

#include <SFML/Graphics.hpp>
#include <vector>

class Tile
{
public:
    enum State {REVEALED, HIDDEN, FLAGGED, EXPLODED};
    Tile(sf::Vector2f position);
    sf::Vector2f getLocation();
    State getState();
    std::array<Tile*,8>& getNeighbors();
    void setState(State _state);
    void setNeighbors(std::array<Tile*,8> _neighbors);
    void onClickLeft();
    void onClickRight();
    void draw();
    sf::Sprite backSprite;
    sf::Sprite frontSprite;
    void setBomb(bool bomb){
        isMine = bomb;
    }
    bool getBomb(){
        return isMine;
    }
    sf::Texture backText;
    sf::Texture frontText;
    sf::Texture& getText();
    void revealNeighbors1();
    sf::Texture one;
    sf::Texture two;
    sf::Texture three;
    sf::Texture four;
    sf::Texture five;
    sf::Texture six;
    sf::Texture seven;
    sf::Texture eight;
    sf::Texture revealed;
    sf::Texture bombText;
    int minesNear();
protected:
    void revealNeighbors();

private:
    State state;
    std::array<Tile*, 8> neighbors;
    bool isMine = false;
    bool isFlag = false;
    sf::Event clickEvent;
};
#endif