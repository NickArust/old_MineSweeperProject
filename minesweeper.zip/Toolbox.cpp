#include "Toolbox.h"
#include "MineSweeper.h"
ToolBox* ToolBox::instance = nullptr;

ToolBox::ToolBox() : window(sf::VideoMode(800,600),"P4 - Minesweeper, Nickolas Arustamyan"){
    gameState = new GameState(); // honestly i do'nt know what im doing so i tried to make it where the b uttons and window are intitizlied in this constructor
    // it mostly works so
    test1.loadFromFile("images/test_1.png");
    test2.loadFromFile("images/test_2.png");
    renew.loadFromFile("images/face_happy.png"); // loads sprites for buttons
    debug.loadFromFile("images/debug.png");

    newGameButton = new Button(sf::Vector2f(368,512),[](){restart();});
    newGameButton->setText(renew); // creates the buttons and assins positions n onclick functions
    debugButton = new Button(sf::Vector2f(496,512),[](){toggleDebugMode();});
    debugButton->setText(debug);
    testButton1 = new Button(sf::Vector2f(560,512),[](){GameState("boards/testboard1.brd");});
    testButton1->setText(test1);
    testButton2 = new Button(sf::Vector2f(624,512),[](){GameState("boards/testboard2.brd");});
    testButton2->setText(test2);

}
ToolBox* ToolBox::getInstance()
{
    if(instance == nullptr)
    {
        instance = new ToolBox();
    }
    return instance;
}