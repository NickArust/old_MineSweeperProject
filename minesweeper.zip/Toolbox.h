#pragma once
#ifndef MINESWEEPER_TOOLBOX_H
#define MINESWEEPER_TOOLBOX_H

#include <SFML/Graphics.hpp>

#include "Tile.h"
#include "Button.h"
#include "GameState.h"
class Button;
class GameState;
class ToolBox
{
public:
    sf::RenderWindow window;
    GameState* gameState = nullptr;
    Button* debugButton;
    Button* newGameButton;
    Button* testButton1;
    Button* testButton2;
    sf::Texture test1;
    sf::Texture test2;
    sf::Texture renew;
    sf::Texture debug;
    bool debugMode = false;
    static ToolBox* getInstance();
    std::vector<std::vector<Tile>> tiles;

private:
    ToolBox();
    static ToolBox* instance;
};

#endif